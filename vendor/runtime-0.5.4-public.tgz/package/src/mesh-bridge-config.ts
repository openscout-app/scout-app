import { DEFAULT_OPENSCOUT_MESH_RELAY_URL, DEFAULT_OPENSCOUT_MESH_RENDEZVOUS_URL } from "@openscout/protocol";
import { createHash } from "node:crypto";
import { closeSync, constants, existsSync, fstatSync, openSync, readFileSync } from "node:fs";
import { join } from "node:path";

/** The one credential/configuration policy used by bridge launch and presence. */
export function validateMeshBridgeConfig(raw: Record<string, unknown>, supportDirectory: string) {
  const relay = new URL(String(raw.relayUrl));
  if (!isMeshBridgeCredentialUrl(relay) || relay.pathname !== "/" || relay.search || relay.hash || raw.dir) {
    throw new Error("invalid bridge launch configuration");
  }
  const tokenFile = join(supportDirectory, "mcp-bridge.token");
  if (raw.tokenFile !== undefined && raw.tokenFile !== tokenFile) throw new Error("invalid bridge token location");
  if (raw.token !== undefined && !isMeshBridgeToken(raw.token)) throw new Error("invalid bridge credential");
  if (raw.tokenKeychainService !== undefined && (
    typeof raw.tokenKeychainService !== "string" || /^[a-zA-Z][a-zA-Z0-9._-]{0,127}$/.exec(raw.tokenKeychainService)?.[0] !== raw.tokenKeychainService
  )) throw new Error("invalid bridge credential reference");
  return {
    relayOrigin: relay.origin,
    token: typeof raw.token === "string" ? raw.token : undefined,
    tokenKeychainService: typeof raw.tokenKeychainService === "string" ? raw.tokenKeychainService : undefined,
    tokenFile,
  };
}

export function isMeshBridgeToken(value: unknown): value is string {
  return typeof value === "string" && /^[\x21-\x7e]{1,8192}$/.exec(value)?.[0] === value;
}

/** Plain HTTP is only for local loopback fixtures, never a remote issuer. */
export function isMeshBridgeCredentialUrl(url: URL): boolean {
  return !url.username && !url.password && (url.protocol === "https:" || (
    url.protocol === "http:" && ["localhost", "127.0.0.1", "[::1]"].includes(url.hostname)
  ));
}

/** Closed issuer audience: self, plus the public default pair. Loopback stays exact-origin. */
export function isMeshBridgeCredentialAudience(relay: URL, destination: URL): boolean {
  if (!isMeshBridgeCredentialUrl(relay) || !isMeshBridgeCredentialUrl(destination)) return false;
  return destination.origin === relay.origin || (
    relay.protocol === "https:" && destination.protocol === "https:"
    && relay.origin === new URL(DEFAULT_OPENSCOUT_MESH_RELAY_URL).origin
    && destination.origin === new URL(DEFAULT_OPENSCOUT_MESH_RENDEZVOUS_URL).origin
  );
}

/** Read-only diagnostics. Omit the audience when host auth is not selected; launch validation stays. */
export function inspectMeshBridgeCredentialConfig(supportDirectory: string, rendezvousUrl?: string): { ok: boolean; detail: string } {
  const path = join(supportDirectory, "mcp-bridge.json");
  if (!existsSync(path)) return { ok: true, detail: "No stored bridge configuration." };
  let raw: Record<string, unknown>;
  try { raw = readMeshBridgeConfigSnapshot(path).value; }
  catch { return { ok: false, detail: "Stored bridge configuration is unreadable or invalid." }; }
  const issues: string[] = [];
  if (raw.dir) issues.push("unsupported dir field");
  if (rendezvousUrl !== undefined) {
    try {
      const relay = new URL(String(raw.relayUrl));
      const destination = new URL(rendezvousUrl);
      if (!isMeshBridgeCredentialAudience(relay, destination)) {
        // Only origins, never userinfo, paths, queries, credentials or the dir value.
        issues.push(`relay/rendezvous pair outside issuer audience (relay=${relay.origin}; rendezvous=${destination.origin})`);
      }
    } catch { issues.push("invalid relay/rendezvous URL pair"); }
  }
  try { validateMeshBridgeConfig(raw, supportDirectory); }
  catch { if (!raw.dir) issues.push("invalid bridge launch configuration"); }
  return { ok: issues.length === 0, detail: issues.length ? `Stored bridge config: ${issues.join("; ")}.` : rendezvousUrl === undefined ? "Stored bridge config is valid." : "Stored bridge config and relay/rendezvous audience are valid." };
}

/** Bounded, owner-controlled snapshot; content identity detects same-mtime edits. */
export function readMeshBridgeConfigSnapshot(path: string): { value: Record<string, unknown>; digest: string; mtimeMs: number } {
  let fd: number | undefined;
  try {
    fd = openSync(path, constants.O_RDONLY | constants.O_NOFOLLOW | constants.O_NONBLOCK);
    const stat = fstatSync(fd);
    if (!stat.isFile() || stat.size > 64 * 1024 || (stat.mode & 0o022) || (process.getuid && stat.uid !== process.getuid())) throw new Error();
    const text = readFileSync(fd, "utf8");
    if (Buffer.byteLength(text) > 64 * 1024) throw new Error();
    const value: unknown = JSON.parse(text);
    if (!value || typeof value !== "object" || Array.isArray(value)) throw new Error();
    return { value: value as Record<string, unknown>, digest: createHash("sha256").update(text).digest("hex"), mtimeMs: stat.mtimeMs };
  } catch { throw new Error("invalid bridge configuration"); }
  finally { if (fd !== undefined) closeSync(fd); }
}

// The download key `scout auth login` saves, and the one question Scout can ask
// the download host with it: does this account have the full web app?
//
// The CLI (`scout web`) and the web server's Scout Pro read model share this so
// there is one place that knows where the key lives and how whoami answers.
// The key itself never leaves this module: callers get where it is stored,
// never what it is.
//
// Store commands (`security`, `secret-tool`) run through the sanctioned async
// exec helper with a time limit, so a locked keychain or an unanswered prompt
// never blocks the web server's event loop.
import { existsSync, mkdirSync, readFileSync, rmSync, writeFileSync } from "node:fs";
import { dirname, join } from "node:path";

import { execSystemFile, ProbeCommandError } from "./system-probes/exec.js";

export const SCOUT_DIST_DEFAULT_URL = "https://console.openscout.app";
export const SCOUT_DIST_KEYS_URL = "https://console.openscout.app/#downloads";
export const DIST_KEY_PREFIX = "osdist_";
export const DIST_KEY_KEYCHAIN_SERVICE = "OPENSCOUT_DIST_KEY";

export function distBaseUrl(env: NodeJS.ProcessEnv): string {
  return (env.OPENSCOUT_DIST_URL?.trim() || SCOUT_DIST_DEFAULT_URL).replace(/\/+$/, "");
}

export function distKeyPath(supportDirectory: string): string {
  return join(supportDirectory, "web", "dist-key");
}

/**
 * Where a saved download key lives. The OS credential store when there is one
 * (macOS Keychain, or the Secret Service via secret-tool on Linux desktops),
 * so the key is encrypted at rest; otherwise a 0600 file, which `scout web
 * status` reports as unencrypted. The key always reaches the store on stdin,
 * never in argv.
 */
export type DistKeyStore = {
  where: string;
  encrypted: boolean;
  read(): Promise<string | null>;
  write(key: string): Promise<boolean>;
  remove(): Promise<boolean>;
};

/** `status` is null when the command couldn't run or ran out of time. */
export type SpawnText = (command: string, args: string[], input?: string) => Promise<{ status: number | null; stdout: string }>;

/**
 * Long enough to answer a Keychain prompt from `scout auth login` or the
 * explicit access check; short enough that a stuck store gives up.
 */
export const DIST_KEY_STORE_TIMEOUT_MS = 60_000;

/** Runs a store command off the event loop, killed after `timeoutMs`. Input goes on stdin. */
export function storeCommandRunner(options: { timeoutMs?: number } = {}): SpawnText {
  const timeoutMs = options.timeoutMs ?? DIST_KEY_STORE_TIMEOUT_MS;
  return async (command, args, input) => {
    try {
      const result = await execSystemFile(command, args, {
        input,
        timeoutMs,
        probeId: `dist-key.${command}`,
        maxStdoutBytes: 64 * 1024,
        maxStderrBytes: 16 * 1024,
      });
      return { status: result.exitCode, stdout: result.stdout };
    } catch (error) {
      // A non-zero exit is an answer ("not found"); anything else (timeout,
      // missing binary, output cap) means the store didn't answer.
      if (error instanceof ProbeCommandError && error.code === "exit") {
        return { status: error.exitCode ?? null, stdout: "" };
      }
      return { status: null, stdout: "" };
    }
  };
}

const spawnText = storeCommandRunner();

const SAFE_KEY = /^[A-Za-z0-9_]+$/;

export function keychainDistKeyStore(spawn: SpawnText = spawnText): DistKeyStore {
  return {
    where: `macOS Keychain (${DIST_KEY_KEYCHAIN_SERVICE})`,
    encrypted: true,
    async read() {
      const result = await spawn("security", ["find-generic-password", "-a", "openscout", "-s", DIST_KEY_KEYCHAIN_SERVICE, "-w"]);
      return result.status === 0 ? result.stdout.trim() || null : null;
    },
    async write(key) {
      // `security -i` reads the command from stdin, so the key stays out of argv.
      if (!SAFE_KEY.test(key)) return false;
      const script = `add-generic-password -U -a openscout -s ${DIST_KEY_KEYCHAIN_SERVICE} -l "Scout download key" -w "${key}"\n`;
      return (await spawn("security", ["-i"], script)).status === 0;
    },
    async remove() {
      return (await spawn("security", ["delete-generic-password", "-a", "openscout", "-s", DIST_KEY_KEYCHAIN_SERVICE])).status === 0;
    },
  };
}

export function secretServiceDistKeyStore(spawn: SpawnText = spawnText): DistKeyStore {
  const attributes = ["service", "openscout-dist", "account", "default"];
  return {
    where: "Secret Service (secret-tool, service openscout-dist)",
    encrypted: true,
    async read() {
      const result = await spawn("secret-tool", ["lookup", ...attributes]);
      return result.status === 0 ? result.stdout.trim() || null : null;
    },
    async write(key) {
      return (await spawn("secret-tool", ["store", "--label=Scout download key", ...attributes], key)).status === 0;
    },
    async remove() {
      return (await spawn("secret-tool", ["clear", ...attributes])).status === 0;
    },
  };
}

export function fileDistKeyStore(supportDirectory: string): DistKeyStore {
  const path = distKeyPath(supportDirectory);
  return {
    where: `${path} (not encrypted)`,
    encrypted: false,
    async read() {
      try {
        return readFileSync(path, "utf8").trim() || null;
      } catch {
        return null;
      }
    },
    async write(key) {
      mkdirSync(dirname(path), { recursive: true });
      writeFileSync(path, `${key}\n`, { mode: 0o600 });
      return true;
    },
    async remove() {
      const existed = existsSync(path);
      rmSync(path, { force: true });
      return existed;
    },
  };
}

/** Encrypted stores first, the file last; every store is read so a key saved before a store appeared is still found. */
export async function defaultDistKeyStores(supportDirectory: string, env: NodeJS.ProcessEnv = process.env): Promise<DistKeyStore[]> {
  const stores: DistKeyStore[] = [];
  if (process.platform === "darwin") stores.push(keychainDistKeyStore());
  else if (env.DBUS_SESSION_BUS_ADDRESS && (await spawnText("secret-tool", ["--version"])).status !== null) {
    stores.push(secretServiceDistKeyStore());
  }
  stores.push(fileDistKeyStore(supportDirectory));
  return stores;
}

export async function readSavedDistKey(stores: DistKeyStore[]): Promise<{ key: string; store: DistKeyStore } | null> {
  for (const store of stores) {
    const key = await store.read();
    if (key) return { key, store };
  }
  return null;
}

/** SCOUT_DIST_KEY first, then the saved key, the same order `scout web` uses. */
export async function resolveDistKey(env: NodeJS.ProcessEnv, stores: DistKeyStore[]): Promise<{ key: string; where: string } | null> {
  const fromEnv = env.SCOUT_DIST_KEY?.trim();
  if (fromEnv) return { key: fromEnv, where: "SCOUT_DIST_KEY" };
  const saved = await readSavedDistKey(stores);
  return saved ? { key: saved.key, where: saved.store.where } : null;
}

/* ── access ─────────────────────────────────────────────────────────────── */

/**
 * What the download host said about this account's full web app, as of one
 * explicit check. Only `granted` and `denied` are answers about the account;
 * every other state means Scout does not know, and must not be read as either.
 */
export type ExpandedWebAccess =
  | { state: "unchecked" }
  | { state: "granted"; checkedAt: number; keyWhere: string; account: { login: string; label: string | null } }
  | { state: "denied"; checkedAt: number; keyWhere: string }
  | { state: "no_credential"; checkedAt: number }
  | { state: "credential_rejected"; checkedAt: number; keyWhere: string }
  | { state: "unavailable"; checkedAt: number; keyWhere: string; reason: string };

export type ExpandedWebAccessState = ExpandedWebAccess["state"];

export type CheckExpandedWebAccessOptions = {
  env?: NodeJS.ProcessEnv;
  stores: DistKeyStore[];
  fetchImpl?: (input: string | URL, init?: RequestInit) => Promise<Response>;
  timeoutMs?: number;
  now?: () => number;
};

function scrub(text: string, key: string): string {
  return key ? text.split(key).join("[key]") : text;
}

/**
 * Asks `GET /v1/dist/whoami` with the saved download key. The host checks the
 * account's entitlement on every call: 200 when it has the full web app, 403
 * `not_entitled` when it doesn't, 401 when the key is revoked or unknown.
 * This makes one network request; call it only when someone asks.
 */
export async function checkExpandedWebAccess(options: CheckExpandedWebAccessOptions): Promise<ExpandedWebAccess> {
  const env = options.env ?? process.env;
  const now = options.now ?? Date.now;
  const resolved = await resolveDistKey(env, options.stores);
  if (!resolved) return { state: "no_credential", checkedAt: now() };
  const { key, where } = resolved;
  const host = distBaseUrl(env);
  let response: Response;
  try {
    response = await (options.fetchImpl ?? fetch)(`${host}/v1/dist/whoami`, {
      headers: { authorization: `Bearer ${key}`, accept: "application/json" },
      signal: AbortSignal.timeout(options.timeoutMs ?? 10_000),
    });
  } catch (error) {
    const detail = error instanceof Error ? error.message : String(error);
    return { state: "unavailable", checkedAt: now(), keyWhere: where, reason: scrub(`Couldn't reach ${host}: ${detail}`, key) };
  }
  const body = await response.json().catch(() => null) as { login?: unknown; label?: unknown; error?: unknown } | null;
  if (response.status === 200 && typeof body?.login === "string" && body.login) {
    return {
      state: "granted",
      checkedAt: now(),
      keyWhere: where,
      account: { login: body.login, label: typeof body.label === "string" && body.label ? body.label : null },
    };
  }
  if (response.status === 403 && body?.error === "not_entitled") return { state: "denied", checkedAt: now(), keyWhere: where };
  if (response.status === 401) return { state: "credential_rejected", checkedAt: now(), keyWhere: where };
  // A 200 without an account, a 403 for some other reason, a 5xx: none of these
  // say what the account has.
  const error = typeof body?.error === "string" ? ` (${body.error})` : "";
  return {
    state: "unavailable",
    checkedAt: now(),
    keyWhere: where,
    reason: scrub(`${host} answered ${response.status}${error}.`, key),
  };
}
